// // server.js
// const express = require("express");
// const cors = require("cors");
// const { queryNatasha } = require("./query");
// const { handleApiIntent } = require("./intentHandlers");
// const conversationManager = require('./conversationManager');

// const app = express();

// // Middleware
// app.use(cors());
// app.use(express.json());

// function generateUserId(req) {
//   const { mobile } = req.body;
//   return mobile;
// }

// app.post("/api/ask-natasha", async (req, res) => {
//   try {
//     const { message, mobile } = req.body;
//     const { authorization } = req.headers;
//     const token = authorization && authorization.split(" ")[1];

//     const userId = generateUserId(req);

//     console.log(
//       `💬 User asked: ${message} (Mobile: ${mobile}) Authorization:${authorization}`
//     );

//     if (!message || message.trim() === "") {
//       return res.status(400).json({
//         error: "Message is required",
//       });
//     }

//     const answer = await queryNatasha(userId, message);

//     console.log(`🤖 Natasha answered: ${JSON.stringify(answer)}`);
//     if (answer.type === "api_intent") {
//       // Pass userId so intent handlers can change per-user session flags
//       const apiAnswer = await handleApiIntent(answer.intent, userId, mobile, token, message);
//       conversationManager.addToHistory(userId, message, apiAnswer);

//       return res.json({
//         message: message,
//         answer: apiAnswer,
//         timestamp: new Date().toISOString(),
//       });
//     } else {
//       res.json({
//         message: message,
//         answer: answer
//           .replace("The answer is ", "")
//           .replace("Answer: ", "")
//           .replace("The answer is: ", "")
//           .trim(),
//         timestamp: new Date().toISOString(),
//       });
//     }
//   } catch (err) {
//     console.error("❌ Natasha error:", err);
//     res.status(500).json({
//       error: "Sorry, something went wrong.",
//     });
//   }
// });

// app.post("/api/clear-session", (req, res) => {
//   const { userId } = req.body;
//   conversationManager.clearSession(userId);
//   res.json({ status: "Session cleared", userId });
// });

// app.get("/api/session-info", (req, res) => {
//   const userId = generateUserId(req);
//   const session = conversationManager.getSession(userId);

//   res.json({
//     userId,
//     historyLength: session.history.length,
//     context: session.context,
//     lastActive: session.lastActive,
//     paymentAwait: session.paymentAwait
//   });
// });

// // Health check
// app.get("/api/health", (req, res) => {
//   res.json({
//     status: "OK",
//     message: "Natasha API is running",
//     timestamp: new Date().toISOString(),
//   });
// });

// const PORT = 3000;
// app.listen(PORT, "0.0.0.0", () =>
//   console.log(`🚀 Natasha API server running on port ${PORT}`)
// );

// server.js
const express = require("express");
const cors = require("cors");
const planner = require("./planner");
const conversationManager = require("./conversationManager");

const app = express();
app.use(cors());
app.use(express.json());

// Generates per-user ID
function generateUserId(req) {
  const { mobile } = req.body || {};
  const session = req.headers["session-id"] || req.ip;
  return mobile ? mobile : `anon-${session}`;
}

app.post("/api/ask-natasha", async (req, res) => {
  try {
    const { message, mobile, actionPayload } = req.body;
    const token =
      req.headers.authorization && req.headers.authorization.split(" ")[1];

    if (!message || message.trim() === "") {
      return res.json({
        blocks: [{ type: "text", text: "Please enter a valid message." }],
      });
    }

    const userId = generateUserId(req);
    const meta = { mobile, token };

    // NEW: All handling done via planner → router → intentHandlers → adapters
    if (actionPayload) {
      // convert actionPayload to planner-friendly message or direct call
      // example: actionPayload = { action:'pay_indexes', payload:{ indexes:[2,4] } }
      response = await planner.handleActionPayload(userId, actionPayload, meta);
    } else {
      response = await planner.handle(userId, message, meta);
    }

    // Store history
    try {
      conversationManager.addToHistory(userId, message, response);
    } catch (err) {
      console.log("History save error:", err);
    }

    return res.json(response);
  } catch (err) {
    console.error("SERVER ERROR:", err);
    return res.status(500).json({
      blocks: [
        {
          type: "text",
          text: "Sorry! Something went wrong. Please try again later.",
        },
      ],
    });
  }
});

// Clear session
app.post("/api/clear-session", (req, res) => {
  const { userId } = req.body;
  conversationManager.clearSession(userId);
  return res.json({ status: "Session cleared", userId });
});

// Health check
app.get("/api/health", (req, res) => {
  return res.json({
    status: "OK",
    running: true,
    timestamp: new Date().toISOString(),
  });
});

// Start
app.listen(3000, () =>
  console.log("🚀 Natasha AI Engine running on port 3000")
);
