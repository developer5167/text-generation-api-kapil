// utils/indexParser.js

// Matches: "2", "2 and 4", "1,3,5", "first", "second", "last", "third"
function extractIndexes(message, listLength) {
  message = message.toLowerCase();

  const wordToIndex = {
    "first": 1,
    "second": 2,
    "third": 3,
    "fourth": 4,
    "fifth": 5,
    "last": listLength
  };

  let indexes = [];

  // Word-based indexes
  for (const word in wordToIndex) {
    if (message.includes(word)) {
      indexes.push(wordToIndex[word]);
    }
  }

  // Number-based indexes: "2", "4", "10"
  const numbers = message.match(/\b\d+\b/g);
  if (numbers) {
    numbers.forEach(n => indexes.push(parseInt(n, 10)));
  }

  // Remove invalid
  indexes = indexes.filter(n => n >= 1 && n <= listLength);

  if (indexes.length === 0) return null;

  return Array.from(new Set(indexes)); // unique
}

module.exports = { extractIndexes };
