// // const { GoogleGenerativeAI } = require("@google/generative-ai");
// // require("dotenv").config();

// // class GeminiSummarizer {
// //   constructor() {
// //     // ✅ SIMPLE - Just API key
// //     this.genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
// //     this.model = this.genAI.getGenerativeModel({ 
// //       model: "gemini-2.5-flash-lite",
      
// //     });
// //   }

// //   async summarizeAccurate(context, question) {
// //     const prompt = `
// // Natasha/Kapil Chits assistant. Use only context.

// // Context: ${context}

// // Q: ${question}

// // A:`;

// //     try {
// //       const result = await this.model.generateContent(prompt);
// //       let answer = result.response.text();
      
// //       // Post-process for accuracy
// //       answer = this.validateAndClean(answer, context);
// //       return answer;
      
// //     } catch (error) {
// //       console.error("❌ Gemini error:", error);
// //       return this.getFallbackResponse(question);
// //     }
// //   }

// //   validateAndClean(answer, context) {
// //     const genericPatterns = [
// //       "I understand you're asking",
// //       "Based on general knowledge",
// //       "Typically, chit funds",
// //       "In most cases"
// //     ];
    
// //     for (const pattern of genericPatterns) {
// //       if (answer.includes(pattern)) {
// //         return "I don't have specific information about that in my knowledge base. Please contact our customer care for accurate details.";
// //       }
// //     }
    
// //     return answer;
// //   }

// //   getFallbackResponse(question) {
// //     if (question.includes('contact') || question.includes('number')) {
// //       return "Please contact Kapil Chits customer care at 1800-123-4343 for assistance.";
// //     }
// //     return "I apologize, I'm having trouble accessing that information right now. Please try again or contact customer care.";
// //   }
// // }

// // module.exports = GeminiSummarizer;



// const { GoogleGenerativeAI } = require("@google/generative-ai");
// const conversationManager = require('./conversationManager');
// require("dotenv").config();

// class GeminiSummarizer {
//   constructor() {
//     this.genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
//     this.modelName = "gemini-2.0-flash-lite"; // Using your model
//   }

//   async summarizeWithContext(userId, context, question) {
//     const session = conversationManager.getSession(userId);
//     const conversationHistory = this.formatHistory(session.history);
    
//     const prompt = this.buildContextAwarePrompt(
//       context, 
//       question, 
//       conversationHistory,
//       session.context
//     );

//     try {
//       const model = this.genAI.getGenerativeModel({ 
//         model: this.modelName,
//         generationConfig: {
//           maxOutputTokens: 250,
//           temperature: 0.3,
//         }
//       });

//       const result = await model.generateContent(prompt);
//       let answer = result.response.text().trim();
      
//       // Update conversation context based on this interaction
//       this.updateConversationContext(userId, question, answer);
      
//       // Add to history
//       conversationManager.addToHistory(userId, question, answer);
      
//       return answer;
      
//     } catch (error) {
//       console.error("❌ Gemini error:", error);
//       return this.getContextAwareFallback(userId, question);
//     }
//   }

//   formatHistory(history) {
//     if (!history || history.length === 0) return "No previous conversation.";
    
//     return history.map(entry => 
//       `User: ${entry.user}\nAssistant: ${entry.bot}`
//     ).join('\n\n');
//   }

//   buildContextAwarePrompt(context, question, history, sessionContext) {
//     return `
// You are Natasha, an AI assistant for Kapil Chits. Maintain conversation context and understand references.

// PREVIOUS CONVERSATION:
// ${history}

// CURRENT CONTEXT:
// ${context}

// USER'S CURRENT QUESTION: "${question}"

// SESSION CONTEXT: ${JSON.stringify(sessionContext, null, 2)}

// INSTRUCTIONS:
// 1. Understand pronouns (he, she, it, they) based on conversation history
// 2. Maintain context from previous messages
// 3. If user refers to something mentioned before, connect it
// 4. Answer naturally and conversationally
// 5. Use only the provided context and conversation history

// RESPONSE:`;
//   }

//   updateConversationContext(userId, question, answer) {
//     const contextUpdates = {};
//     const q = question.toLowerCase();
//     const a = answer.toLowerCase();

//     // Detect what we're talking about
//     if (q.includes('founder') || q.includes('vaman') || a.includes('founder')) {
//       contextUpdates.lastTopic = 'founder';
//       contextUpdates.mentionedFounder = true;
//     }
    
//     if (q.includes('payment') || q.includes('pay') || q.includes('due')) {
//       contextUpdates.lastTopic = 'payment';
//       contextUpdates.mentionedPayment = true;
//     }
    
//     if (q.includes('chit') && (q.includes('detail') || q.includes('plan'))) {
//       contextUpdates.lastTopic = 'chit_details';
//     }
    
//     if (q.includes('contact') || q.includes('number') || q.includes('call')) {
//       contextUpdates.lastTopic = 'contact';
//     }

//     // Extract entities for future reference
//     if (a.includes('sri vaman rao')) {
//       contextUpdates.founderName = 'Sri Vaman Rao';
//     }
    
//     if (a.match(/\d{4}/)) { // If we mentioned a year
//       const yearMatch = a.match(/\b(19|20)\d{2}\b/);
//       if (yearMatch) contextUpdates.mentionedYear = yearMatch[0];
//     }

//     conversationManager.updateContext(userId, contextUpdates);
//   }

//   getContextAwareFallback(userId, question) {
//     const session = conversationManager.getSession(userId);
//     const lastTopic = session.context.lastTopic;
    
//     // Context-aware fallbacks
//     if (lastTopic === 'founder') {
//       return "The founder's name is Sri Vaman Rao. Kapil Chits was established in 1981.";
//     }
    
//     if (lastTopic === 'payment') {
//       return "For payment-related queries, please contact our customer care at 1800-123-4343.";
//     }
    
//     if (lastTopic === 'contact') {
//       return "You can reach us at 1800-123-4343 or visit your nearest branch.";
//     }

//     // Generic fallback
//     return "I apologize, I'm having trouble accessing that information. Please contact customer care at 1800-123-4343 for assistance.";
//   }
// }

// module.exports = GeminiSummarizer;

// GeminiSummarizer.js
const { GoogleGenerativeAI } = require("@google/generative-ai");
const conversationManager = require("./conversationManager");
require("dotenv").config();

class GeminiSummarizer {
  constructor() {
    this.genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    this.modelName = "gemini-2.0-flash-lite";
  }

  async summarizeWithContext(userId, context, question) {
    const session = conversationManager.getSession(userId);
    const prompt = `
You are Natasha, an AI assistant. Answer the user's question using the following context only.
If context is irrelevant, give the best helpful answer based on that domain.

CONTEXT:
${context}

USER:
"${question}"

PREVIOUS HISTORY:
${session.history
  .map((h) => `User: ${h.user}\nAssistant: ${h.bot}`)
  .join("\n")}

RESPONSE:
`;

    try {
      const model = this.genAI.getGenerativeModel({
        model: this.modelName,
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 250,
        },
      });

      const result = await model.generateContent(prompt);
      let answer = result.response.text().trim();
      return answer;
    } catch (err) {
      console.error("Summarizer error:", err);
      return "Sorry, I'm unable to fetch that information right now.";
    }
  }
}

module.exports = GeminiSummarizer;
