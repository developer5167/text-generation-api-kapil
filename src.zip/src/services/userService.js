const axios = require('axios');
const baseUrl = 'https://testapi.kapilchitskarnataka.com';

const GetSubscriberdues = async (mobile, token) => {
  const response = await fetch(`${baseUrl}/api/GetSubscriberdues?Mobileno=${mobile}`,
    {
        method: 'GET',
        headers: {

            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`  // Replace with actual API key
        }
    }

  );
  if (!response.ok) {
     throw new Error("Something went wrong");
  }
  const responseBody = await response.json();
  return responseBody;
  
  
     
};
const GetTransactions = async (groupcodetickectno, token) => {
  const response = await fetch(`${baseUrl}/api/GetSubscriberChitDetailsbasedongroupcode?groupcodetickectno=${groupcodetickectno}`,
    {
        method: 'GET',
        headers: {

            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`  // Replace with actual API key
        }
    }

  );
  if (!response.ok) {
     throw new Error("Something went wrong");
  }
  const responseBody = await response.json();
  return responseBody;
  
  
     
};
const GetChitDetails = async (mobile, token) => {
  // https://testapi.kapilchitskarnataka.com/api/GetSubscriberChitDetails?Mobileno=9705772178

  const url = `${baseUrl}/api/GetSubscriberChitDetails?Mobileno=${mobile}`
  console.log(url);

  const response = await fetch(url,
    {
        method: 'GET',
        headers: {

            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`  // Replace with actual API key
        }
    }

  );
  if (!response.ok) {
     throw new Error("Something went wrong");
  }
  const responseBody = await response.json();  
  
  return responseBody;     
};
const GetAuctionDetails = async (mobile, token) => {
  const response = await fetch(`${baseUrl}/api/GetSubscriberauctionDetails?Mobileno=${mobile}`,
    {
        method: 'GET',
        headers: {

            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`  // Replace with actual API key
        }
    }

  );
  if (!response.ok) {
     throw new Error("Something went wrong");
  }
  const responseBody = await response.json();  
  console.log(response.body);
  
  
  return responseBody;     
};
const vacantChitsBranches = async ( token) => {
  const response = await fetch(`${baseUrl}/api/getvacentbranchnames`,
    {
        method: 'GET',
        headers: {

            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`  // Replace with actual API key
        }
    }

  );
  if (!response.ok) {
    throw new Error("Something went wrong");
  }
  const responseBody = await response.json();  
  console.log(response.body);
  
  
  return responseBody;     
};

//  https://testapi.kapilchitskarnataka.com/api/GetSubscriberauctionDetailsAll?Mobileno=9705772178
module.exports = {
  GetSubscriberdues,
  GetChitDetails,
  GetTransactions,
  GetAuctionDetails,
  vacantChitsBranches


};
