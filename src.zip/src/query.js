// query.js
const fs = require("fs");
const { pipeline } = require("@xenova/transformers");
const { getCollection } = require("./chromaClient");
const GeminiSummarizer = require("./GeminiSummarizer");
const geminiSummarizer = new GeminiSummarizer();
const conversationManager = require("./conversationManager");
const { isApiIntent } = require("./intentHandlers");

// Utility: Cosine similarity
function cosineSimilarity(a, b) {
  let dot = 0,
    normA = 0,
    normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] ** 2;
    normB += b[i] ** 2;
  }
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

function hasBothChitDetails(message) {
  const hasChitNumber = /[A-Z]{2,6}\d{1,4}[A-Z]?-\d{1,3}/.test(message);

  const amountPatterns = [
    /₹\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?/,
    /Rs\.?\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?/i,
    /\b\d{1,3}(?:,\d{3})*(?:\.\d{2})?\s*(?:rupees?|RS?\.?)/i,
    /\b\d{4,}\b/,
    /amount\s*:?\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?/i,
    /chit\s*value\s*:?\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?/i,
  ];

  const hasAmount = amountPatterns.some((pattern) => pattern.test(message));

  console.log(
    "hasBothChitDetails - Amount:",
    hasAmount,
    "Chit Number:",
    hasChitNumber
  );

  return hasChitNumber && hasAmount;
}

// Intent detection using embeddings
async function detectIntent(userId, question) {
  // Check per-user paymentAwait first
  const session = conversationManager.getSession(userId);
  const paymentAwait =session.paymentAwait
  // If user is in payment-await mode, check ONLY if message contains payment info
  if (paymentAwait) {

    const last = conversationManager.getLastList(userId);

    // Detect index references
    const indexes = extractIndexes(question, last.list?.length || 0);

    if (indexes) {
        return "proceed_payment";  // forward to handler
    }

    // If user provides chit number + amount normally
    if (hasBothChitDetails(question)) {
        return "proceed_payment";
    }

    // If message still looks payment-related
    if (/pay|amount|rs|₹|rupees/.test(question)) {
        return "please enter both chit number and amount...";
    }

    // Otherwise normal intent processing continues
}

  const embedder = await pipeline(
    "feature-extraction",
    "Xenova/all-MiniLM-L6-v2"
  );
  const intents = JSON.parse(
    fs.readFileSync("./intent_embeddings.json", "utf-8")
  );

  const queryEmb = Array.from(
    (await embedder(question, { pooling: "mean", normalize: true })).data
  );

  let bestIntent = null;
  let bestScore = -1;

  for (const intent of intents) {
    for (const emb of intent.embeddings) {
      const score = cosineSimilarity(queryEmb, emb);
      if (score > bestScore) {
        bestScore = score;
        bestIntent = intent.name;
      }
    }
  }

  console.log(
    `🧭 Detected intent: ${bestIntent} (score: ${bestScore.toFixed(3)})`
  );
  if (bestScore < 0.6) return null; // threshold for confidence
  return bestIntent;
}

// Main query function
async function queryNatasha(userId, question) {
  const collection = await getCollection();
  const intent = await detectIntent(userId, question);

  console.log(
    `\n🔍 Querying knowledge base: ${
      intent || "general"
    }.txt\n user ${userId} asked: ${question}`
  );
  if (intent && isApiIntent(intent)) {
    return { type: "api_intent", intent };
  }

  let results = await collection.query({
    queryTexts: [question],
    nResults: 5,
    where: intent ? { module: intent + ".txt" } : undefined,
  });

  // Fallback if no results
  if (!results || !results.documents || results.documents[0].length === 0) {
    console.log("🔄 No intent match found, searching globally...");
    results = await collection.query({
      queryTexts: [question],
      nResults: 7,
    });
  }

  if (!results.documents || results.documents[0].length === 0) {
    return "🤖 I couldn't find relevant information about that in our knowledge base. Could you please rephrase your question or ask about our chit fund services, company information, or contact details?";
  }

  const combinedText = results.documents[0]
    .filter((doc) => doc && doc.trim().length > 10)
    .slice(0, 5)
    .join(" \n\n ");

  const answer = await geminiSummarizer.summarizeWithContext(
    userId,
    combinedText,
    question
  );
  return answer;
}

module.exports = { queryNatasha };
