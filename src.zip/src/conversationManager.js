// // conversationManager.js
// class ConversationManager {
//   constructor() {
//     this.sessions = new Map();
//     this.sessionTimeout = 15 * 60 * 1000;
//   }

//   getSession(userId) {
//     this.cleanupExpiredSessions();

//     if (!this.sessions.has(userId)) {
//       this.sessions.set(userId, {
//         userId,
//         context: {},
//         history: [],
//         paymentAwait: false,
//         lastList: null,       // <-- NEW HERE
//         lastListType: null,   // <-- NEW HERE
//         lastListRaw: null,    // <-- NEW HERE (raw data)
//         lastActive: Date.now(),
//         createdAt: Date.now()
//       });
//     }

//     const session = this.sessions.get(userId);
//     session.lastActive = Date.now();
//     return session;
//   }

//   updateContext(userId, newContext) {
//     const session = this.getSession(userId);
//     session.context = { ...session.context, ...newContext };
//     return session;
//   }

//   setPaymentAwait(userId, value) {
//     const session = this.getSession(userId);
//     session.paymentAwait = value;
//   }

//   getPaymentAwait(userId) {
//     return this.getSession(userId).paymentAwait;
//   }

//   // ---------- NEW METHODS FOR LIST MEMORY ----------
//   setLastList(userId, type, list) {
//     const session = this.getSession(userId);
//     session.lastListType = type; // "dues", "chits", "transactions"
//     session.lastListRaw = list;
//   }

//   getLastList(userId) {
//     const session = this.getSession(userId);
//     return {
//       type: session.lastListType,
//       list: session.lastListRaw
//     };
//   }

//   clearLastList(userId) {
//     const session = this.getSession(userId);
//     session.lastListType = null;
//     session.lastListRaw = null;
//   }
// }

// module.exports = new ConversationManager();
// conversationManager.js
class ConversationManager {
  constructor() {
    this.sessions = new Map();
    this.sessionTimeout = 20 * 60 * 1000; // 20 minutes
  }

  getSession(userId) {
    this.cleanupExpiredSessions();

    if (!this.sessions.has(userId)) {
      this.sessions.set(userId, {
        userId,
        context: {},
        history: [],
        paymentAwait: false,
        lastListType: null,
        lastListRaw: null,
        lastEntities: {},
        lastActive: Date.now(),
        createdAt: Date.now(),
      });
    }

    const session = this.sessions.get(userId);
    session.lastActive = Date.now();
    return session;
  }

  addToHistory(userId, user, bot) {
    const s = this.getSession(userId);
    s.history.push({ user, bot, timestamp: new Date().toISOString() });
    if (s.history.length > 8) {
      s.history = s.history.slice(-8);
    }
  }

  // Payment-await flag
  setPaymentAwait(userId, val) {
    this.getSession(userId).paymentAwait = val;
  }

  getPaymentAwait(userId) {
    return this.getSession(userId).paymentAwait;
  }

  // LAST LIST MEMORY
  setLastList(userId, type, list) {
    const s = this.getSession(userId);
    s.lastListType = type;
    s.lastListRaw = list;
  }

  getLastList(userId) {
    const s = this.getSession(userId);
    return { type: s.lastListType, list: s.lastListRaw };
  }

  clearLastList(userId) {
    const s = this.getSession(userId);
    s.lastListType = null;
    s.lastListRaw = null;
  }

  cleanupExpiredSessions() {
    const now = Date.now();
    for (const [uid, s] of this.sessions.entries()) {
      if (now - s.lastActive > this.sessionTimeout) {
        this.sessions.delete(uid);
      }
    }
  }

  clearSession(userId) {
    this.sessions.delete(userId);
  }
}

module.exports = new ConversationManager();
