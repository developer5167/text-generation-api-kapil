// controllers/userController.js
const userService = require("../services/userService");

const formatDueDetails =
  require("../templates/fetchTemplates").formatDueDetails;
const formatChitDetails =
  require("../templates/fetchTemplates").formatChitDetails;
const formatForPayChitDue =
  require("../templates/fetchTemplates").formatForPayChitDue;
const conversationManager = require("../conversationManager");

const GetSubscriberdues = async (mobile, token) => {
  try {
    const response = await userService.GetSubscriberdues(mobile, token);
    conversationManager.setLastList(mobile, "dues", response);
    return formatDueDetails(response);
  } catch (err) {
    console.error("GetSubscriberdues error:", err);
    return "I'm sorry! I couldn't fetch your subscriber dues right now.";
  }
};

const GetChitDetails = async (mobile, token) => {
  try {
    const response = await userService.GetChitDetails(mobile, token);
    conversationManager.setLastList(mobile, "chits", response);
    return formatChitDetails(response);
  } catch (err) {
    console.error("GetChitDetails error:", err);
    return "I'm sorry! I couldn't fetch your chit details at the moment.";
  }
};

const DoPayment = async (mobile, token) => {
  try {
    const duesList = await userService.GetSubscriberdues(mobile, token);
    return formatForPayChitDue(duesList.slice(0, 1));
  } catch (err) {
    console.error("DoPayment error:", err);
    return "I'm sorry! I couldn't fetch your payment details right now.";
  }
};

const payDueAmount = async (userId, mobile, token, chitNumber, amount) => {
  try {
    const duesList = await userService.GetSubscriberdues(mobile, token);
    const findingDue = duesList.find(
      (due) => due.pchitno === chitNumber && due.pnetpayable >= amount
    );

    if (!findingDue) {
      return `Either the chit number ${chitNumber} is invalid or the amount ₹${amount} exceeds the net payable amount. Please check and try again.`;
    }

    // success
    conversationManager.setPaymentAwait(userId, false);
    return `Payment of ₹${amount} for chit number ${chitNumber} has been successfully processed.`;

  } catch (err) {
    console.error("payDueAmount error:", err);
    conversationManager.setPaymentAwait(userId, false); // ensure cleanup
    return "Something went wrong while processing your payment. Please try again later.";
  }
};

const transactions = async (mobile, token, groupcodetickectno) => {
  try {
    const data = await userService.GetTransactions(
      mobile,
      token,
      groupcodetickectno
    );

    if (data.lstSubscribertransDTO.length === 0) {
      return "No recent transactions found.";
    }

    let message = "Here are your recent transactions:\n\n";
    data.lstSubscribertransDTO.forEach((d, index) => {
      message += `${index + 1}.
Transaction ID: ${d.ptransno}
Group Code: ${d.pgroupcode}
Date: ${d.ptransdate}
Amount: ₹${d.ptotalamount}
------------------------------\n`;
    });
    return message;
  } catch (err) {
    console.error("transactions error:", err);
    return "I'm sorry! I couldn't fetch your transactions right now.";
  }
};

module.exports = {
  GetSubscriberdues,
  GetChitDetails,
  DoPayment,
  payDueAmount,
  transactions,
};
