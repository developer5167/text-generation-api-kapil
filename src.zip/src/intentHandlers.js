// // intentHandlers.js
// const {
//   GetSubscriberdues,
//   GetChitDetails,
//   DoPayment,
//   payDueAmount,
//   transactions,
// } = require("./controllers/userController");
// const { extractIndexes } = require("./indexParser");

// const conversationManager = require("./conversationManager");

// // Registry of all API-based intent handlers
// const intentHandlers = {
//   subscriber_dues: {
//     requiresAuth: true,
//     handler: async (userId, mobile, token, message) => {
//       return await GetSubscriberdues(mobile, token);
//     },
//     authMessage:
//       "Please login with a valid mobile number to fetch your subscriber dues.",
//   },

//   chit_details: {
//     requiresAuth: true,
//     handler: async (userId, mobile, token, message) => {
//       return await GetChitDetails(mobile, token);
//     },
//     authMessage:
//       "Please login with a valid mobile number to fetch your chit details.",
//   },

//   do_payment: {
//     requiresAuth: true,
//     handler: async (userId, mobile, token, message) => {
//       // Mark only this user's session as waiting for chit+amount
//       conversationManager.setPaymentAwait(userId, true);
//       console.log("paymentAwait set true for", userId);
//       return await DoPayment(mobile, token);
//     },
//     authMessage:
//       "Please login with a valid mobile number to proceed with the payment.",
//   },

//  proceed_payment: {
//   requiresAuth: true,
//   handler: async (userId, mobile, token, message) => {
    
//     const last = conversationManager.getLastList(userId);
//     if (!last.list || last.type !== "dues") {
//       return "Please show your dues first using 'show me my dues'.";
//     }

//     const indexes = extractIndexes(message, last.list.length);
//     if (!indexes) {
//       return "Please specify which items (e.g., 'pay for 2 and 4').";
//     }

//     let responses = [];
//     for (const i of indexes) {
//       const due = last.list[i - 1];
//       if (!due) continue;

//       const result = await payDueAmount(
//         userId,
//         mobile,
//         token,
//         due.pchitno,
//         due.pnetpayable
//       );
//       responses.push(`${due.pchitno} – ₹${due.pnetpayable}: ${result}`);
//     }

//     return responses.join("\n");
//   },
// },

//   transactions: {
//     requiresAuth: true,
//     handler: async (userId, mobile, token, groupcodetickectno) => {
//       if (!extractGroupCodeTicketNo(groupcodetickectno)) {
//         return "Please provide a valid group code ticket number to fetch your transactions.";
//       }
//       return await transactions(mobile, token, groupcodetickectno);
//     },
//     authMessage:
//       "Please login with a valid mobile number to proceed with the payment.",
//   },

//   // Add new intents here - NO CODE CHANGES NEEDED ELSEWHERE
// };

// // Check if intent requires API call
// function isApiIntent(intent) {
//   return intentHandlers.hasOwnProperty(intent);
// }
// function extractListIndexes(message) {
//   // match: "2", "2 and 4", "1, 3, 5"
//   const matches = message.match(/\b\d+\b/g);
//   if (!matches) return null;
//   return matches.map((n) => parseInt(n));
// }
// // Handle API intent uniformly
// async function handleApiIntent(intent, userId, mobile, token, message) {
//   const handlerConfig = intentHandlers[intent];

//   if (!handlerConfig) {
//     throw new Error(`No handler configured for intent: ${intent}`);
//   }

//   // Check authentication for protected intents
//   if (handlerConfig.requiresAuth && (!mobile || !mobile.trim() || !token)) {
//     return handlerConfig.authMessage;
//   }
//   return await handlerConfig.handler(userId, mobile, token, message);
// }

// /* ---------------- helper extractors (unchanged) ---------------- */

// function extractChitNumber(message) {
//   const text = message.trim();
//   const chitPattern = /[A-Z]{2,6}\d{1,4}[A-Z]?-\d{1,3}/gi;
//   const matches = text.match(chitPattern);
//   if (matches && matches.length > 0) {
//     return matches[0].toUpperCase();
//   }
//   const labeledPattern =
//     /chit\s*(?:number|code|id|no\.?)?\s*:?\s*([A-Z0-9-]+)/gi;
//   const labeledMatch = labeledPattern.exec(text);
//   if (labeledMatch && labeledMatch[1]) {
//     return labeledMatch[1].toUpperCase().trim();
//   }
//   const commonPhrases = [
//     /chit\s+([A-Z0-9-]+)/gi,
//     /for\s+chit\s+([A-Z0-9-]+)/gi,
//     /pay\s+(?:for\s+)?([A-Z0-9-]+)/gi,
//     /against\s+chit\s+([A-Z0-9-]+)/gi,
//   ];
//   for (const pattern of commonPhrases) {
//     const match = pattern.exec(text);
//     if (match && match[1] && /[A-Z]/.test(match[1])) {
//       return match[1].toUpperCase().trim();
//     }
//   }
//   return null;
// }
// function extractGroupCodeTicketNo(message) {
//   return extractChitNumber(message);
// }
// function extractAmount(message) {
//   const text = message.trim();
//   const amountPatterns = [
//     { pattern: /₹\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/, group: 1 },
//     { pattern: /Rs\.?\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/i, group: 1 },
//     {
//       pattern: /amount\s*:?\s*₹?\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/i,
//       group: 1,
//     },
//     {
//       pattern: /chit\s*value\s*:?\s*₹?\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/i,
//       group: 1,
//     },
//     {
//       pattern: /(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)\s*(?:rupees?|RS?\.?)/i,
//       group: 1,
//     },
//     {
//       pattern:
//         /pay\s*(?:amount)?\s*:?\s*₹?\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/i,
//       group: 1,
//     },
//     {
//       pattern:
//         /paid?\s*(?:amount)?\s*:?\s*₹?\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/i,
//       group: 1,
//     },
//     { pattern: /(\d{4,})\s*(?=\s*(?:rupees?|amount|pay|₹|Rs\.?))/i, group: 1 },
//     { pattern: /\b(\d{4,6})\b/, group: 1 },
//   ];
//   for (const { pattern, group } of amountPatterns) {
//     const match = text.match(pattern);
//     if (match && match[group]) {
//       const amountStr = match[group].replace(/,/g, "");
//       const amount = parseFloat(amountStr);
//       if (!isNaN(amount) && amount > 0) {
//         if (amount >= 100 && amount <= 1000000) {
//           return amount;
//         }
//       }
//     }
//   }
//   const paymentKeywords = /(pay|paid|amount|due|balance|rupees?|₹|rs\.?)/i;
//   if (paymentKeywords.test(text)) {
//     const allNumbers = text.match(/\d{3,6}/g);
//     if (allNumbers) {
//       for (const numStr of allNumbers) {
//         const amount = parseInt(numStr);
//         if (amount >= 100 && amount <= 1000000) {
//           return amount;
//         }
//       }
//     }
//   }
//   return null;
// }

// module.exports = {
//   intentHandlers,
//   isApiIntent,
//   handleApiIntent,
// };

// intentHandlers.js
const conversationManager = require("./conversationManager");
const adapters = require("./apiAdapters/exampleAdapters");
const responses = require("./responses/builder");
const GeminiSummarizer = require("./GeminiSummarizer");

const summarizer = new GeminiSummarizer();

// ------------ TOOL INTENT HANDLERS -------------

async function handle_show_dues(userId, mobile, token) {
  try {
    const data = await adapters.GetSubscriberdues(mobile, token);

    const items = data.map((d, i) => ({
      index: i + 1,
      id: d.pchitno || `chit-${i + 1}`,
      title: d.pgroupcode || d.pchitno || "Chit",
      amount: d.pnetpayable || 0,
      raw: d,
    }));

    conversationManager.setLastList(userId, "dues", items);

    return {
      blocks: [
        { type: "text", text: "Here are your dues:" },
        { type: "list", listType: "dues", items },
        {
          type: "text",
          text: "You can say: 'pay 1', 'pay 2 and 3', 'pay the last one'",
        },
      ],
      timestamp: new Date().toISOString(),
    };
  } catch (err) {
    console.error(err);
    return responses.text("Sorry, I couldn't fetch your dues.");
  }
}

async function handle_proceed_payment(userId, mobile, token, message, slots) {
  try {
    const { list, type } = conversationManager.getLastList(userId);

    if (!list || list.length === 0 || type !== "dues") {
      return responses.text("Please say 'show my dues' first.");
    }

    let targets = [];

    // If user gave indexes
    if (slots.indexes && slots.indexes.length) {
      targets = slots.indexes
        .map((i) => list[i - 1])
        .filter(Boolean);
    } 
    // If they gave chit numbers directly
    else if (slots.chitNumbers && slots.chitNumbers.length) {
      targets = list.filter((it) =>
        slots.chitNumbers.includes(it.id)
      );
    } else {
      return responses.text(
        "Please tell me which dues to pay. Example: 'pay 1' or 'pay 2 and 3'"
      );
    }

    const results = [];
    let total = 0;

    for (const t of targets) {
      const amt = t.amount;
      total += amt;
      const payRes = await adapters.PayDue(mobile, token, t.id, amt);

      if (payRes && payRes.upiUrl) {
        results.push({
          id: t.id,
          amount: amt,
          status: "pending",
          upiUrl: payRes.upiUrl,
        });
      } else {
        results.push({
          id: t.id,
          amount: amt,
          status: payRes.success ? "success" : "failed",
        });
      }
    }

    const pending = results.filter((r) => r.upiUrl);

    if (pending.length > 0) {
      const combined = pending.reduce((s, p) => s + p.amount, 0);
      const combinedUpi = `upi://pay?pa=9999999999@upi&pn=KapilChits&am=${combined}&tn=ChitPayment`;
      return {
        blocks: [
          {
            type: "text",
            text: `Paying ${results.length} dues. Total ₹${combined}`,
          },
          { type: "payment_result", results },
          { type: "qr", upiUrl: combinedUpi },
        ],
      };
    }

    return responses.paymentResult(results);
  } catch (err) {
    console.error(err);
    return responses.text("Payment failed. Please try again.");
  }
}

// ------------ KNOWLEDGE (NON-TOOL) ANSWERS -----------------

const fs = require("fs");
const path = require("path");

async function searchAndAnswer(userId, mobile, token, message) {
  try {
    // Build context from text files present in ./pdfs (knowledge base)
    const dataDir = path.join(__dirname, "pdfs");
    let combined = "";
    if (fs.existsSync(dataDir)) {
      const files = fs.readdirSync(dataDir);
      for (const file of files) {
        if (!file.toLowerCase().endsWith(".txt")) continue;
        try {
          const content = fs.readFileSync(path.join(dataDir, file), "utf8");
          combined += "\n\n" + content;
        } catch (e) {
          // ignore read errors
        }
      }
    }

    // If no combined content, fallback to asking the LLM with just the question
    const contextToSend = combined && combined.trim().length > 20 ? combined : null;

    const answer = await summarizer.summarizeWithContext(
      userId,
      contextToSend || message,
      message
    );

    return {
      blocks: [{ type: "text", text: answer || "I couldn't find information on that." }],
      timestamp: new Date().toISOString(),
    };
  } catch (err) {
    console.error("searchAndAnswer error:", err);
    return {
      blocks: [{ type: "text", text: "Sorry, I couldn't get that information." }]
    };
  }
}

// -------------------------------------------------------------

module.exports = {
  handleApiIntent: async (
    intent,
    userId,
    mobile,
    token,
    message,
    slots
  ) => {
    switch (intent) {
      case "subscriber_dues":
        return await handle_show_dues(userId, mobile, token);

      case "proceed_payment":
      case "do_payment":
        return await handle_proceed_payment(
          userId,
          mobile,
          token,
          message,
          slots
        );

      default:
        return {
          blocks: [
            {
              type: "text",
              text: "I don't recognize this action yet.",
            },
          ],
        };
    }
  },

  searchAndAnswer,
};
